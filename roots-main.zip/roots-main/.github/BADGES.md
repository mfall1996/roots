# Open Source Badges

[![License](https://img.shields.io/github/license/frivas/roots)](LICENSE)
[![Issues](https://img.shields.io/github/issues/frivas/roots)](https://github.com/frivas/roots/issues)
[![Pull Requests](https://img.shields.io/github/issues-pr/frivas/roots)](https://github.com/frivas/roots/pulls)
[![Contributors](https://img.shields.io/github/contributors/frivas/roots)](https://github.com/frivas/roots/graphs/contributors)
[![Last Commit](https://img.shields.io/github/last-commit/frivas/roots)](https://github.com/frivas/roots/commits/main)

<!-- Add these badges to the top of your README.md for better visibility -->

---
